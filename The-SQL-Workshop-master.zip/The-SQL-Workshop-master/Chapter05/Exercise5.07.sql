SELECT *
FROM Customers
WHERE FirstName = 'Joe' AND Phone LIKE '(310)%';
