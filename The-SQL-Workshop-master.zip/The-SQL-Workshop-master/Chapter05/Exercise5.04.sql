SELECT FirstName AS 'Customers from LA', Phone 
FROM Customers
WHERE Phone LIKE '(310)%';
