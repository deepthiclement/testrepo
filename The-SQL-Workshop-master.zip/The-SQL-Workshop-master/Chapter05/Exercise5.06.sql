SELECT MiddleName, LastName, Phone 
FROM Customers
WHERE FirstName IS NULL;
