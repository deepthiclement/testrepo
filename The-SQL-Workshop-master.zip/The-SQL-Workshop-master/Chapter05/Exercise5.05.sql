SELECT FirstName, LastName, Phone 
FROM Customers
WHERE FirstName LIKE '___';
