SELECT ProductCategoryName AS CATEGORY, ProductCategoryID AS ID 
FROM ProductCategories;
SELECT ProductCategoryName AS 'PRODUCT CATEGORY', ProductCategoryID AS ID 
FROM ProductCategories;
