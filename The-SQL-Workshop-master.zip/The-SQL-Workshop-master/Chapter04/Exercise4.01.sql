use PACKT_ONLINE_SHOP; 
SELECT ProductCategoryID, ProductCategoryName 
FROM ProductCategories;
