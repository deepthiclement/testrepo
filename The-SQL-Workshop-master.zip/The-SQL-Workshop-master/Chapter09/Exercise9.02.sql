USE packt_online_shop;

GRANT EXECUTE ON PROCEDURE packt_online_shop.spFilterProductsByNRP TO 'TEMP_ACCOUNT_1';

packt_online_shop.spFilterProductsByNRP

SHOW GRANTS FOR TEMP_ACCOUNT_1;
