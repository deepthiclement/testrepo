USE PACKT_ONLINE_SHOP;
DELETE FROM products
    WHERE ProductName = 'tomato sauce'; 
